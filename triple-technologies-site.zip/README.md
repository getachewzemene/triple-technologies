# Triple Technologies website

Static site built with Astro. No client framework; about 60 lines of vanilla JS.

    npm install
    npm run dev       # local development
    npm run build     # outputs to dist/
    npm run preview

## Before launch
- Add real contact details and/or a form endpoint in `src/data/site.ts`. Empty channels are hidden; the form needs an email or endpoint to work.
- Set `SITE_URL` in Vercel (your production URL) to enable canonical and Open Graph absolute URLs.

## Deploy
Import the repo in Vercel. Framework preset: Astro. Build command `npm run build`, output `dist`.

## Editing content
All copy for services, reasons and process steps lives in `src/data/site.ts`. Design tokens are in `src/styles/global.css`.
