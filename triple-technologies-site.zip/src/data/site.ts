/**
 * Single source of truth for site content and contact details.
 *
 * CONTACT: fill in the channels you actually use. Anything left empty is simply
 * not shown. The contact form works as follows:
 *   1. If `formEndpoint` is set, it POSTs there (Formspree, Web3Forms, etc.).
 *   2. Otherwise, if `contact.email` is set, it opens the visitor's email app.
 */
export const site = {
  name: 'Triple Technologies',
  description:
    'Triple Technologies is an Ethiopian technology company providing software development, IT training and consultancy, CCTV and security systems, and digital services for businesses and organizations.',
  contact: {
    email: '',
    phone: '',
    telegram: '', // e.g. 'https://t.me/yourhandle'
    whatsapp: '', // e.g. 'https://wa.me/251XXXXXXXXX'
  },
  formEndpoint: '',
};

export const services = [
  {
    id: 'software',
    name: 'Software development',
    short: 'software',
    situation:
      'Your team runs on spreadsheets, paper and chat threads, and work slips through the gaps.',
    body:
      'We design and build software around how your business actually operates, and connect it to the systems you already use.',
    items: [
      'Custom business and management systems',
      'Websites and web applications',
      'Mobile apps',
      'Integrations and automation',
    ],
  },
  {
    id: 'training',
    name: 'IT training and consultancy',
    short: 'training',
    situation:
      'You have the tools, but your people are not getting the value out of them.',
    body:
      'Hands-on training for your staff and straight advice for your decisions: what to buy, how to set it up, and how to get your team confident using it.',
    items: [
      'Practical IT training for staff',
      'Review of your current systems and setup',
      'Technology planning and purchasing advice',
      'Ongoing guidance as your needs change',
    ],
  },
  {
    id: 'cctv',
    name: 'CCTV and security solutions',
    short: 'security',
    situation:
      'You cannot see what happens at your premises when you are not there.',
    body:
      'We assess your site, plan camera coverage around what matters, install it cleanly, and set up viewing so you can check in when you need to.',
    items: [
      'Site survey and system design',
      'Camera installation and cabling',
      'Remote viewing on phone and computer',
      'Maintenance and upgrades',
    ],
  },
  {
    id: 'digital',
    name: 'Digital services and social media',
    short: 'digital services',
    situation:
      'Customers look for you online and find very little that reflects your business.',
    body:
      'We set up and manage your presence on the platforms your customers use, with consistent branding and clear ways for people to reach you.',
    items: [
      'Social media management',
      'Content and post design',
      'Business pages and online profiles',
      'Website updates and maintenance',
    ],
  },
];

export const reasons = [
  {
    title: 'Practical before impressive',
    body: 'We recommend what fits your budget and the way you work, not the most complicated option.',
  },
  {
    title: 'Explained in plain language',
    body: 'Every choice is explained in terms of your business, so you can decide with confidence.',
  },
  {
    title: 'Planned together',
    body: 'Software, security, training and your online presence are considered as one picture, not as separate purchases.',
  },
  {
    title: 'Made to be used',
    body: 'Technology only pays off when people use it. We train your team and plan for what happens after launch.',
  },
];

export const steps = [
  { title: 'Conversation', body: 'We listen to how your business runs and what is getting in the way.' },
  { title: 'Proposal', body: 'You get a clear scope, timeline and price before any work starts.' },
  { title: 'Delivery', body: 'We build or install, and keep you updated at each stage.' },
  { title: 'Handover and support', body: 'We train your team and stay reachable once it is running.' },
];
